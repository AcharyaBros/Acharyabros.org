

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// 1. Setup Variables (at the very top)
var playerX = 200;
var playerY = 200;
var score = 0;
var myTimer = 300; // 300 frames = 10 seconds
var badCorner = randomNumber(1, 4);
var scoreCounted = false;

function draw() {
  // 2. Draw Map (Clears screen every frame)
  fill("red"); rect(0, 0, 200, 200);
  fill("blue"); rect(200, 0, 200, 200);
  fill("yellow"); rect(0, 200, 200, 200);
  fill("green"); rect(200, 200, 200, 200);

  // 3. Game Logic Phase
  if (myTimer > 0) {
    // Game is active
    myTimer = myTimer - 1;

    // Movement
    if (keyDown("right")) { playerX = playerX + 5; }
    if (keyDown("left")) { playerX = playerX - 5; }
    if (keyDown("up")) { playerY = playerY - 5; }
    if (keyDown("down")) { playerY = playerY + 5; }

    // Screen Boundaries
    if (playerX < 15) { playerX = 15; }
    if (playerX > 385) { playerX = 385; }
    if (playerY < 15) { playerY = 15; }
    if (playerY > 385) { playerY = 385; }

    // Timer Display
    fill("black");
    textSize(40);
    text(Math.ceil(myTimer / 30), 185, 50);

  } else {
    // 4. TIME IS UP: WIN/LOSS CHECK
    var playerCorner = 0;
    
    // LINE CHECK: Auto-lose if touching the lines (x=200 or y=200)
    if (playerX == 200 || playerY == 200) {
      fill("black");
      textSize(40);
      text("ON THE LINE!", 90, 160);
      text("YOU LOSE!", 100, 210);
      score = 0; // Reset score to 0
    } else {
      // Corner Detection (only if not on a line)
      if (playerX < 200 && playerY < 200) { playerCorner = 1; }
      else if (playerX > 200 && playerY < 200) { playerCorner = 2; }
      else if (playerX < 200 && playerY > 200) { playerCorner = 3; }
      else { playerCorner = 4; }

      textSize(45);
      if (playerCorner == badCorner) {
        fill("black");
        text("YOU LOSE!", 90, 210);
        score = 0; // Reset score to 0
      } else {
        fill("white");
        text("SAFE!", 140, 210);
        if (scoreCounted == false) {
          score = score + 1;
          scoreCounted = true;
        }
      }
    }

    // 5. REPLAY BUTTON
    fill("white");
    textSize(20);
    text("Press 'R' for Next Round", 90, 320);
    if (keyDown("r")) {
      playerX = 200;
      playerY = 200;
      myTimer = 300;
      badCorner = randomNumber(1, 4);
      scoreCounted = false;
    }
  }

  // 6. Draw Player and Score UI
  fill("black");
  ellipse(playerX, playerY, 30, 30);
  
  fill("black");
  textSize(20);
  text("Score: " + score, 15, 30);
}


  
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
